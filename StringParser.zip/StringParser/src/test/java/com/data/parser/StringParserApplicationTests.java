package com.data.parser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StringParserApplicationTests {

	@Test
	void contextLoads() {
	}

}
